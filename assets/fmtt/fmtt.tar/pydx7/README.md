# pydx7
A Python Implementation of the Yamaha DX7 Engine
