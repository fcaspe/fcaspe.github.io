from .synth import dx7_synth,midi_note
__all__ =['dx7_synth','midi_note']